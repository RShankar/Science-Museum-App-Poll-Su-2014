package com.example.mods;

import java.util.ArrayList;
import java.util.List;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.os.Build;

import com.parse.FindCallback;
import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;


public class Result extends ActionBarActivity {
	private static final String EXTRA_MESSAGE = "com.example.mods";
	public int age_choice; 
	public String age_choice_s;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_result);
		
		Intent mIntent = getIntent();
		age_choice = mIntent.getIntExtra("age_choice",0 );
		

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		
		Parse.initialize(this, "cf04S0tckY7z7ESeW0EUlRladgjHXMC4qYvRUrDO", "Lk02UZdNqxU1AEjosW7QUFzw7Ib0aqtCBYrP1zBN");
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery("data");
		query.whereEqualTo("age", age_choice);
		query.findInBackground(new FindCallback<ParseObject>() {
			@Override
			public void done(List<ParseObject> list, ParseException e) {
				double exh0 = 0, exh1 = 0, exh2 = 0, exh3 = 0, exh4 = 0;
				int counter = 0;
				if(list.size() > 0) {													
					for(int i = 0; i < list.size(); i++) {
						if(list.get(i).getString("exhibit").equalsIgnoreCase("Runway To Rockets"))
							exh0++;
						else if((list.get(i).getString("exhibit").equalsIgnoreCase("Living In The Everglades")))
							exh1++;
						else if((list.get(i).getString("exhibit").equalsIgnoreCase("The Ecodiscovery Center")))
							exh2++;
						else if((list.get(i).getString("exhibit").equalsIgnoreCase("The Powerful You")))
							exh3++;
						else if((list.get(i).getString("exhibit").equalsIgnoreCase("Traveling Exhibit")))
							exh4++;
						counter++;
					}
				}
				if(exh0 != 0)
					exh0 = (exh0 /counter) * 100;
				if(exh1 != 0)
					exh1 = (exh1 /counter) * 100;
				if(exh2 != 0)
					exh2 = (exh2 /counter) * 100;
				if(exh3 != 0)
					exh3 = (exh3 /counter) * 100;
				if(exh4 != 0)
					exh4 = (exh4 /counter) * 100;
				
				TextView tv0 = (TextView) findViewById(R.id.exh0);
				TextView tv1 = (TextView) findViewById(R.id.exh1);
				TextView tv2 = (TextView) findViewById(R.id.exh2);
				TextView tv3 = (TextView) findViewById(R.id.exh3);
				TextView tv4 = (TextView) findViewById(R.id.exh4);
				tv0.setText("Runway To Rockets: " + (int)exh0 + "%");
				tv1.setText("Living In The Everglades: " + (int)exh1 + "%");
				tv2.setText("The Ecodiscovery Center: " + (int)exh2 + "%");
				tv3.setText("The Powerful You: " + (int)exh3 + "%");
				tv4.setText("Traveling Exhibit: " + (int)exh4 + "%");
			}
			
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.result, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_result,
					container, false);
			return rootView;
		}
	}
	
	 public void goBack(View view) {
	        Intent intent = new Intent(this, Entering.class);
	        startActivity(intent);
	        this.finish();
	    }

}
