package com.example.mods;


import android.app.DialogFragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

//parse imports
import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseObject;

public class Leaving extends ActionBarActivity implements OnItemSelectedListener {
	String exhibit = "Runway To Rockets";
	String hello = "hello";
	int age = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_leaving);
		
		//parse initalizing
		Parse.initialize(this, "cf04S0tckY7z7ESeW0EUlRladgjHXMC4qYvRUrDO", "Lk02UZdNqxU1AEjosW7QUFzw7Ib0aqtCBYrP1zBN");
		
		//creates the spinner
		Spinner spin = (Spinner) findViewById(R.id.leaving_age_imput);
		spin.setOnItemSelectedListener(this);
		
	
		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.leaving, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_leaving,
					container, false);
			return rootView;
		}
	}

	//Gets input from radio Buttons
	public void onRadioButtonClicked(View view) {
		
		// Is the button now checked?
		 boolean checked = ((RadioButton) view).isChecked();
	    
	    // Check which radio button was clicked
	    switch(view.getId()) {
	        case R.id.exhibit0:
	                exhibit = "Runway To Rockets";
	            break;
	        case R.id.exhibit1:
	            	exhibit = "Living In The Everglades";
	            break;
	        case R.id.exhibit2:
	            	exhibit = "The Ecodiscovery Center";
	            break;
	        case R.id.exhibit3:
	            	exhibit = "The Powerful You";
	            break;
	        case R.id.exhibit4:
	        		exhibit = "Traveling Exhibit";
	            break;            
	    }
	}
	
	//opens up the fragment and should send info to parse
	public void goToDialog(View view){
		
	//sends info to parse	
	ParseObject data = new ParseObject("data");
	data.put("exhibit", exhibit);
	data.put("age", age);
	data.saveInBackground();
		
	//opens dialog	
	DialogFragment newFragment = new Dialog();
	newFragment.show(getFragmentManager(), hello);	
	}
	
	//goes to main menu
	public void goBack(View view) {
		//TextView tv = (TextView) findViewById(R.id.test);;
		//tv.setText(exhibit); 
        Intent intent = new Intent(this, MainActivity.class);
        startActivityForResult(intent, 0);
        this.finish();
    }

	
	//collects info from spinner
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position ,
			long id) {
	
			
		switch(position) {
        case 0:
                age = 0;
            break;
        case 1:
            	age = 1;
            break;
        case 2:
            	age = 2;
            break;
        case 3:
            	age = 3;
            break; }
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub
		
	}
	}
	

