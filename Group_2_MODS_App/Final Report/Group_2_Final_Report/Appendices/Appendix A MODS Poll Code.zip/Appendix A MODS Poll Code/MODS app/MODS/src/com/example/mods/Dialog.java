package com.example.mods;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * A simple {@link android.support.v4.app.Fragment} subclass. Activities that
 * contain this fragment must implement the
 * {@link Dialog.OnFragmentInteractionListener} interface to handle interaction
 * events. Use the {@link Dialog#newInstance} factory method to create an
 * instance of this fragment.
 * 
 */
public class Dialog extends DialogFragment {
    protected static final String EXTRA_MESSAGE = null;

	@Override
    public android.app.Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        
        builder.setMessage(R.string.thanks)
               .setPositiveButton(R.string.menu, new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {               
                	   Intent intent = new Intent(getActivity(), MainActivity.class);
                	   startActivity(intent);
                	   getActivity().finish();
                   }
               })
               .setNeutralButton(R.string.back, new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                	   dismiss();;
                   }
               })
               .setNegativeButton(R.string.exit, new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                	  getActivity().finish();
                   }
               });
        // Create the AlertDialog object and return it
        return builder.create();
    }

	@Override
	public void show(FragmentManager manager, String tag) {
		// TODO Auto-generated method stub
		super.show(manager, tag);
	}
    
    
}